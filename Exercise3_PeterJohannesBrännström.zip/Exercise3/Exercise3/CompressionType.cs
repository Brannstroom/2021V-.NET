﻿using System.IO.Compression;

namespace Exercise3
{
    enum CompressionType
    {

        Compress = CompressionMode.Compress,
        Decompress = CompressionMode.Decompress,

    }
}
